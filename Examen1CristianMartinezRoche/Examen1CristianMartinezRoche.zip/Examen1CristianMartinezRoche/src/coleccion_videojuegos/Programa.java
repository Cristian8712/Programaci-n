package coleccion_videojuegos;

import java.util.Scanner;

public class Programa {

	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		String listaConsolas[] = new String[0];
		String listaJuegos[] = new String [0];
		boolean listaDisponibles[][]= new boolean[0][0];
		
		System.out.print("¿Cuántas consolas vas a introducir?: ");
		int numConsolas = entrada.nextInt();
		entrada.nextLine();
		
		
		listaConsolas = Metodos.leerArrayConsolas (numConsolas, entrada);
		System.out.print("¿Cuántos videojuegos vas a introducir?: ");
		int numJuegos = entrada.nextInt();
		entrada.nextLine();

		listaJuegos = Metodos.leerArrayJuegos(numJuegos, entrada);
		
		listaDisponibles = Metodos.leerDisponibles(listaConsolas, listaJuegos, entrada);
		int opcion = 0 ;
		
		do {
			System.out.println("===== MENU =====\r\n"
					+ "1. Mostrar consolas\r\n"
					+ "2. Mostrar juegos\r\n"
					+ "3. Ver disponibilidad\r\n"
					+ "4. Juego más compatible\r\n"
					+ "5. Juegos por consola\r\n"
					+ "6. Salir\r\n"
					+ "Seleccione una opción:");
			opcion = entrada.nextInt();
			entrada.nextLine();
			
			switch (opcion) {
			case 1:
				Metodos.mostrarConsolas(listaConsolas);
				break;
			case 2:
				Metodos.mostrarJuegos(listaJuegos);
				break;
			case 3:
				Metodos.mostrarDisponibilidad(listaDisponibles, listaConsolas, listaJuegos);	
				break;
			case 4:
				//Metodos.juegoMasCompatible(listaConsolas, listaJuegos);	
				break;
			case 5:
							
				break;
			case 6:
								
				break;

			default:
				break;
			}
		} while (opcion != 6);
	
		
	}

}
