package pipati;

import java.util.Scanner;

public class Metodos {

	public static int numAleatorio (int max, int min){
		int valor = (int) (Math.random() * (max - min + 1) + min);
		return valor;
		
	}
	
	public static int quienGana (int jug1, int jug2) {
		int gana = 0;
		if (jug1 == 0 && jug2 ==1 ) {
			gana = 2;
		}
		else if (jug1 == 0 && jug2 ==2 ) {
			gana = 1;
		}
		else if (jug1 == 0 && jug2 ==0 ) {
			gana = 0;
		}
		else if (jug1 == 1 && jug2 ==2 ) {
			gana = 2;
		}
		else if (jug1 == 1 && jug2 ==0 ) {
			gana = 1;
		}
		else if (jug1 == 1 && jug2 ==1 ) {
			gana = 0;
		}
		else if (jug1 == 2 && jug2 ==0 ) {
			gana = 2;
		}
		else if (jug1 == 2 && jug2 ==1 ) {
			gana = 1;
		}
		else if (jug1 == 2 && jug2 ==2 ) {
			gana = 0;
		}
		
		return gana;
	}
	
	
	public static String muestraJugada (int resultado) {
		String jugada = "";
		if (resultado == 0) {
			jugada = "piedra";
		}
		else if (resultado == 1) {
			jugada = "papel";
		}
		else if (resultado == 2) {
			jugada = "tijera";
		}
		
		return jugada;
		
	}
	
	public static int jugadaValida(Scanner entrada) {
		int resultado = 0;
		boolean valided = true;
		do {
			
		
		System.out.println("¿Piedra (0), papel (1) o tijera (2)? ");
		int opcion = entrada.nextInt();
		if (opcion != 0 || opcion != 1 || opcion != 2) {
			System.out.println("Opción incorrecta");
			valided = false;
		}
		else {
			
			resultado = opcion;
		}
		
		return resultado;
		} while (valided = false);
		
		
	}
	
	
}
