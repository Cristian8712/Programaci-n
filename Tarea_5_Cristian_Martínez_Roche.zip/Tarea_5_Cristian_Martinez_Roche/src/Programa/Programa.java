package Programa;

import java.util.Random;
import java.util.Scanner;

import clases.Enemigo;
import clases.Jefe_Final;
import clases.Juego;

public class Programa {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		boolean jugarDeNuevo;
		
		do {
			Juego partida = new Juego();
			System.out.println("Bienvendio al Juego:");
			System.out.print("¿Cuántas rondas quieres jugar?: ");
			int rondas = entrada.nextInt();
			entrada.nextLine();
			partida.setnRondas(rondas);
			System.out.print("Introduce tu nombre: ");
			String nombre = entrada.nextLine();
			System.out.println("Elige tu clase:\r\n" + "1. Mago\r\n" + "2. Guerrero");
			System.out.print("Elección: ");
			int opcionClase = entrada.nextInt();
			switch (opcionClase) {
			case 1:
				partida.nuevoMago(nombre);
				System.out.println("Has elegido el mago " + nombre + ", maestro en las artes oscuras.");
				break;
			case 2:
				partida.nuevoGuerrero(nombre);
				System.out.println("Has elegido el guerrero " + nombre + ", destructor de mundos.");
				break;
			default:
				System.out.println("Opción seleccionada no válida");
				Random num = new Random();
				int nuevaClase = num.nextInt(2) + 1;
				opcionClase = nuevaClase;
				if (nuevaClase == 1) {
					partida.nuevoMago(nombre);
					System.out.println(
							"El destino quiso que fueras el mago " + nombre + ", maestro en las artes oscuras.");
				} else {
					partida.nuevoGuerrero(nombre);
					System.out.println("El destino quiso que fueras el guerrero " + nombre + ", destructor de mundos.");
				}
				break;
			}
			partida.iniciarJuego();
			while (!partida.finalJuego() && !partida.getJugador().muerto()) {
				partida.setRonda(partida.getRonda() + 1);
				Enemigo actualEnemigo = partida.getSiguiente();

				while (actualEnemigo != null && !actualEnemigo.muerto() && !partida.getJugador().muerto()) {
					System.out.println("Ronda: " + partida.getRonda() + "/" + partida.getnRondas());
					System.out.println("Estás luchando contra: " + actualEnemigo.toString());
					System.out.println("Eres: " + partida.getJugador().toString());

					partida.getJugador().mostrarMenu();
					int accion = entrada.nextInt();
					partida.getJugador().ejecutarAccion(accion, actualEnemigo);

					if (!actualEnemigo.muerto()) {
						System.out.println(actualEnemigo.getNombre() + " ataca a " + partida.getJugador().getNombre());
						actualEnemigo.atacar(partida.getJugador());
					}
				}

				if (actualEnemigo != null && actualEnemigo.muerto()) {
					System.out.println("El enemigo " + actualEnemigo.getNombre() + " ha sido vencido!!!");
					partida.terminarRonda();
				}
			}
			
			if (!partida.getJugador().muerto() && partida.finalJuego()) {
                System.out.println("----------------------------------------------------------");
                System.out.println("¡Has derrotado a las oleadas enemigas!");
                System.out.println("Pero de repente, el suelo comienza a temblar...");
                System.out.println("¡La adrenalina del combate recorre tus venas!");
                System.out.println("TUS HERIDAS SANAN Y RECUPERAS TODOS TUS RECURSOS, UNA FUERZA RECORRE TODO TU CUERPO...");
                partida.getJugador().resetear();
                partida.getJugador().despertar();
                Jefe_Final jefeFinal = new Jefe_Final("Rey Demonio Balthazar");
                System.out.println("La horda ruje y entre aullidos y lamentos aparece el " + jefeFinal.getNombre());
                System.out.println("----------------------------------------------------------");
                
               
                while (!jefeFinal.muerto() && !partida.getJugador().muerto()) {
                    System.out.println(jefeFinal.toString());
                    System.out.println("Eres: " + partida.getJugador().toString());
                    
                    partida.getJugador().mostrarMenu();
                    int accion = entrada.nextInt();
                    entrada.nextLine();

                    partida.getJugador().ejecutarAccion(accion, jefeFinal);

                    if (!jefeFinal.muerto()) {
                        System.out.println(jefeFinal.getNombre() + " desata un ataque brutal contra " + partida.getJugador().getNombre());
                        jefeFinal.atacar(partida.getJugador());
                    }
                }

                if (jefeFinal.muerto()) {
                    System.out.println("¡¡HAS DERROTADO AL JEFE FINAL!!");
                }
            }
			System.out.println("--- FIN DE LA PARTIDA ---");
			if (partida.getJugador().muerto()) {
				System.out.println("Has caído en combate, las hordas del mal han vencido");
			} else {
				System.out.println("¡¡Enhorabuena has vencido!!La luz prevalecerá sobre la oscuridad.");
			} 
			
			System.out.print("\n¿Quieres jugar otra vez? (s/n): ");
            String respuesta = entrada.nextLine().toLowerCase();
            jugarDeNuevo = respuesta.equals("s");
           
		} while (jugarDeNuevo);
		
		System.out.print("Gracias por jugar, nos vemos pronto.");
		entrada.close();
	}

}
