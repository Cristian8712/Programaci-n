package clases;

public class Personaje {
	
	private int vida;
	private int vidaInicial;
	private int ataque;
	private int defensa;
	private String nombre;
	
	public Personaje() {
		};
	
	public Personaje(int vida, int ataque, int defensa, String nombre) {
		this.vida = vida;
		this.vidaInicial= vida;
		this.ataque = ataque;
		this.defensa = defensa;
		this.nombre = nombre;
		
	}

	
	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public int getVidaInicial() {
		return vidaInicial;
	}

	public void setVidaInicial(int vidaInicial) {
		this.vidaInicial = vidaInicial;
	}

	public int getAtaque() {
		return ataque;
	}

	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}

	public int getDefensa() {
		return defensa;
	}

	public void setDefensa(int defensa) {
		this.defensa = defensa;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void atacar(Personaje otro) {
		int danyo = this.ataque - otro.getDefensa();
		if (danyo <= 0) {
			danyo = 1;
			System.out.println("El ataque ha sido repelido casi en su totalidad, pero sufres rasguños");
		}
		otro.setVida(otro.getVida() - danyo);
	}
	
	public boolean muerto() {
		return this.vida <=0;		
	}

	@Override
	public String toString() {
		return this.nombre + " => Vida: " + this.vida + "/" + this.vidaInicial;
	}
	
}
