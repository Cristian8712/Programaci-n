package clases;

import java.util.ArrayList;
import java.util.Random;

public class Juego {

	private static String[] nombresEnemigos = {"Gorbad", "Malcador", "Petronella", "Azhag", "Wurrzag"};
	
	private ArrayList<Enemigo> enemigos;
	private PersonajeJugable jugador;
	int nRondas;
	int ronda;
	
	public Juego() {
		this.enemigos = new ArrayList<>();
	}
	
	public PersonajeJugable getJugador() {
		return jugador;
	}
	public void setJugador(PersonajeJugable jugador) {
		this.jugador = jugador;
	}
	public int getnRondas() {
		return nRondas;
	}
	public void setnRondas(int nRondas) {
		this.nRondas = nRondas;
	}
	public int getRonda() {
		return ronda;
	}
	public void setRonda(int ronda) {
		this.ronda = ronda;
	}
	
	public static String getNombreAleatorio() {
		Random random = new Random();
		return nombresEnemigos[random.nextInt(nombresEnemigos.length)];
	}
	
	public void iniciarJuego() {
		this.enemigos.clear();
		for(int i = 0; i < this.nRondas; i++) {
			this.enemigos.add(new Enemigo(getNombreAleatorio()));
		}
		this.ronda = 0;
	}
	
	public Enemigo getSiguiente() {
		if (!this.enemigos.isEmpty()) {
			return this.enemigos.get(0);
		}
		return null;
	}
	
	public boolean terminarRonda() {
		Enemigo enemigoActual = getSiguiente();
		if(enemigoActual != null && enemigoActual.muerto()) {
			this.enemigos.remove(0);
			return true;
		}
		return false;	
	}
	
	public void nuevoGuerrero(String nombre) {
		Random aleatorio = new Random();
		int aleatorioVida = aleatorio.nextInt(101) + 100;
		this.jugador = new Guerrero(aleatorioVida, nombre);
	}
	
	public void nuevoMago(String nombre) {
		Random aleatorio = new Random();
		int aleatorioVida = aleatorio.nextInt(51) + 100;
		this.jugador = new Mago(aleatorioVida, nombre);
	}
	
	public boolean finalJuego() {
		return this.enemigos.isEmpty();
	}
	
	
	
}
