package clases;

public class Guerrero extends PersonajeJugable {
	
	public static final int FUERZA = 15;
	public static final int DEFENSA = 10;
	public static final int POCIONES = 2;

	private int pociones;
	
	public Guerrero(int vida,String nombre) {
		super(vida, FUERZA, DEFENSA, nombre);
		this.pociones = POCIONES;
	}

	@Override
	public void curar() {
		if(this.pociones > 0) {
			this.setVida(getVidaInicial());
			System.out.println("Usaste una poción, recuperas el 100% de tu vida");
			this.pociones--;
		}else {
			System.out.println("No te quedan pociones, sigue luchando");
		}
	}

	@Override
	public void resetear() {
		super.resetear();
		this.pociones = POCIONES;
	}

	@Override
	public String toString() {
		return super.toString() + "; Pociones: " + this.pociones;
	}

	@Override
	public void ejecutarAccion(int opcion, Personaje otro) {
        if (opcion == 1) {
            System.out.println(this.getNombre() + " ataca a " + otro.getNombre());
            this.atacar(otro);
        } else if (opcion == 2) {
            this.curar();
        } else {
            System.out.println("Opción incorrecta.");
        }
    }
	
	@Override
    public void despertar() {
            this.setAtaque(this.getAtaque() * 2);
            this.setDefensa(this.getDefensa() + 5);
            System.out.println("¡¡" + this.getNombre().toUpperCase() + " ENTRA EN MODO BERSERKER!!");
            System.out.println("La furia ciega duplica tu fuerza y endurece tu piel.");
        }
    }

