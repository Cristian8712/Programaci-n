package clases;

public interface InterfazJugable {

	public void curar();
	public void mostrarMenu();
	public void ejecutarAccion(int opcion, Personaje otro);
	
}
