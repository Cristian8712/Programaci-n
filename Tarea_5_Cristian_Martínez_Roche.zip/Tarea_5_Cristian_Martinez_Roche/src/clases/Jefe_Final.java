package clases;

public class Jefe_Final extends Enemigo {

	public Jefe_Final(String nombre) {
        super(nombre);
 
        this.setVidaInicial(250);
        this.setVida(250);
        this.setAtaque(20); 
        this.setDefensa(8); 
    }

    @Override
    public String toString() {
        return "El " + super.toString() + ".";
    }

}
