package clases;

public class Mago extends PersonajeJugable {
	
	public static final int FUERZA_MAGIA = 20;
	public static final int FUERZA_SIN_MAGIA = 5;
	public static final int DEFENSA = 5;
	public static final int MAGIA = 10;
	
	private int magia;

	public Mago(int vida,String nombre) {
		super(vida, FUERZA_MAGIA, DEFENSA, nombre);
		this.magia = MAGIA;
	}
	
	public void atacar(Personaje otro) {
		super.atacar(otro);
		if(this.magia > 0) {
			this.magia--;
		}
		if(this.magia == 0){
		this.setAtaque(FUERZA_SIN_MAGIA);
		}
	}
	
	@Override
	public void curar() {
		if (this.magia > 0) {
			this.setVida(this.getVida() + this.getAtaque());
			if(this.getVida() > this.getVidaInicial()) {
				this.setVida(this.getVidaInicial());	
			}
			System.out.println("Has usado un hechizo de curación, tu vida ahora es " + this.getVida());
			this.magia--;
		}else {
				this.setVida(this.getVida() + FUERZA_SIN_MAGIA);
				if(this.getVida() > this.getVidaInicial()) {
					this.setVida(this.getVidaInicial());
					System.out.println("No te queda poder mágico, pero consigues recuperate y tu vida ahora es " + this.getVida());
				}
			}	
		}
	

	@Override
	public void ejecutarAccion(int opcion, Personaje otro) {
        if (opcion == 1) {
            System.out.println(this.getNombre() + " ataca a " + otro.getNombre());
            this.atacar(otro);
        } else if (opcion == 2) {
            this.curar();
        } else {
            System.out.println("Opción incorrecta.");
        }
    }
		
	@Override
	public void resetear() {
		super.resetear();
		this.magia = MAGIA;
	}
	@Override
    public void despertar() {
            this.setVidaInicial(this.getVidaInicial() + 100); 
            this.setVida(this.getVidaInicial()); 
            this.magia = 99; 
            this.setAtaque(this.getAtaque() + 15);
            System.out.println("¡¡" + this.getNombre().toUpperCase() + " SE CONVIERTE EN GRAN DRUIDA!!");
            System.out.println("La naturaleza te otorga vitalidad masiva y poder mágico inagotable.");
        }
    
	@Override
	public String toString() {
		
		return super.toString() + "; Magia: " + this.magia;
	}

}
