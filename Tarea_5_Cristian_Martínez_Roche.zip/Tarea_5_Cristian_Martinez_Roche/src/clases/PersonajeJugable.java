package clases;

public abstract class PersonajeJugable extends Personaje implements InterfazJugable {


	public PersonajeJugable(int vida, int ataque, int defensa, String nombre) {
		super(vida, ataque, defensa, nombre);
		
	}
	
	public void resetear() {
		this.setVida(this.getVidaInicial());
	}
	
	public void mostrarMenu() {
		System.out.println("Acciones:\r\n"
				+ "1. Atacar\r\n"
				+ "2. Curar\r\n"
				+ "Elige:");
	}
	
	public abstract void despertar(); 
}
