package clases;

import java.util.Random;

public class Enemigo extends Personaje {



	public Enemigo(String nombre) {
		super();
		Random valor = new Random();
		
		this.setNombre(nombre);
		this.setVidaInicial(valor.nextInt(81) + 20);
		this.setVida(this.getVidaInicial());
		this.setAtaque(valor.nextInt(9) + 5);
		this.setDefensa(valor.nextInt(3) + 1);
	}

}
